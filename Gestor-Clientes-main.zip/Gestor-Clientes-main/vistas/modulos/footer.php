<footer class="main-footer">
	
	<strong>Copyright &copy; 2023 <a href="#" target="_blank">Nankima</a>.</strong>

	Todos los derechos reservados.

	
	
		</div>

</footer>